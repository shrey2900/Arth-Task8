import os
import subprocess as sr
import getpass
import socket
while True:
    psswd=getpass.getpass("Enter password to proceed :  ")
    if psswd == "tt":
        break
    else:
        print('\t > Please Enter Correct Password\n')

os.system('clear')
print('\n\n\t\t\t\t\t',end='')
os.system('tput setaf 3')
print('''Automated Program for RHEL8
*************************************************************************************************''')
    
os.system('tput setaf 2')
print('''\n\nWhich system you want to operate :-
\t\t1. Remote System
\t\t2. Local System
\n\t [[  Type '3' To Exit  ]]''')
sys=input('\n\tEnter your option :  ')


#Exit
if sys=='3':
    os.system('clear')
    exit()


#Local System
elif sys=='2':
    while True:
        os.system('clear')
        os.system('tput setaf 7')
        print('''
    \t\t 1. Show Current Date
    \t\t 2. Show Current Time
    \t\t 3. Show My Private IP
    \t\t 4. Configure Web Server
    \t\t 5. Configure HDFS Cluster
    \t\t 6. Ping a Server
    \t\t 7. Exit''')
        a=input('Enter your choice : ')
        if a=='1':
            op=sr.getstatusoutput("date +%d/%m/%Y")
            print("\n\t\tToday's date is  >>  {}\n".format(op[1]))
            input('\nPress enter key to continue...')
        elif a=='2':
            op=sr.getstatusoutput('date +%I:%M:%S')
            print("\n\t\tCurrent Time Is  >>  {}\n".format(op[1]))
            input('\nPress enter key to continue...')
        elif a=='3':
            print('\t\t>> Please Wait...\n')
            hn=socket.gethostname()
            ip=socket.gethostbyname(hn)
            print("Your Private IP Is  >>  {}".format(ip))
            input('\nPress enter key to continue...')
        elif a=='4':
            print('\n\t\t >>Please wait...')
            op=sr.getstatusoutput('dnf install -y httpd')
            if op[0]==0:
                print('\t\t>>  HTTPD Installed  <<')
            op=sr.getstatusoutput('systemctl start httpd')
            if op[0]==0:
                print('\t\t>>  Service Started  <<')
            obj=open('/var/www/html/default.html','w+')
            txt='Hi, this is a pre-created webpage'
            obj.writelines(txt)
            obj.close()
            print("\t\t>>  An html Page In The Name of 'default.html' Is Created \n\t\tIn The Root Directory of The Web Server <<")
            print('\t\t>>  Web Server Configured  <<')
            input('\nPress enter key to continue...')
        elif a=='5':
            print('''\t\tWhat Do You Want To Configure?
            \t\t  1. NameNode
            \t\t  2. DataNode
            \t\t  3. Client''')
            ch=input('\t\tEnter Your Selection :  ')
            if ch=='1':
                loc=input('Enter The Directory :  ')
                port=input('Enter The Port No. :  ')
                print('\n\t\t>> Please Wait...')
                op=sr.getstatusoutput('rpm -i jdk-8u171-linux-x64.rpm --force')
                if op[0]==0:
                    print('\n\t\t>>  JDK Installed  <<')
                op=sr.getstatusoutput('rpm -i hadoop-1.2.1-1.x86_64.rpm --force')
                if op[0]==0:
                    print('\n\t\t>>  Hadoop Installed  <<')
                obj=open('/etc/hadoop/hdfs-site.xml','w+')
                hn=socket.gethostname()
                ip=socket.gethostbyname(hn)
                txt='<configuration>\n<property>\n<name>dfs.name.dir</name>\n<value>{}</value>\n</property>\n</configuration>'.format(loc)
                obj.writelines(txt)
                obj.close()
                obj=open('/etc/hadoop/core-site.xml','w+')
                txt='<configuration>\n<property>\n<name>fs.default.name</name>\n<value>hdfs://{0}:{1}</value>\n</property>\n</configuration>'.format(ip,port)
                obj.writelines(txt)
                obj.close()
                os.system('rm -rf {}'.format(loc))
                os.system('mkdir {}'.format(loc))
                print('\n\t\t>>  Formatting NameNode Directory  <<')
                print('\n\t\t>>  Enter "Y" In The Upcoming Prompt :-')
                os.system('hadoop namenode -format')
                os.system('systemctl stop firewalld')
                os.system('setenforce 0')
                op=sr.getstatusoutput('hadoop-daemon.sh start namenode')
                print('\n\t\t>>  NameNode Configured AND Started  <<')
                input('\nPress enter key to continue...')
            elif ch=='2':
                ip=input('Enter IP of NameNode :  ')
                loc=input('Enter The Directory :  ')
                port=input('Enter The Port No. :  ')
                print('\n\t\t>> Please Wait...')
                op=sr.getstatusoutput('rpm -i jdk-8u171-linux-x64.rpm --force')
                if op[0]==0:
                    print('\n\t\t>>  JDK Installed  <<')
                op=sr.getstatusoutput('rpm -i hadoop-1.2.1-1.x86_64.rpm --force')
                if op[0]==0:
                    print('\n\t\t>>  Hadoop Installed  <<')
                obj=open('/etc/hadoop/hdfs-site.xml','w+')
                txt='<configuration>\n<property>\n<name>dfs.data.dir</name>\n<value>{}</value>\n</property>\n</configuration>'.format(loc)
                obj.writelines(txt)
                obj.close()
                obj=open('/etc/hadoop/core-site.xml','w+')
                txt='<configuration>\n<property>\n<name>fs.default.name</name>\n<value>hdfs://{0}:{1}</value>\n</property>\n</configuration>'.format(ip,port)
                obj.writelines(txt)
                obj.close()
                os.system('rm -rf {}'.format(loc))
                os.system('mkdir {}'.format(loc))
                os.system('systemctl stop firewalld')
                os.system('setenforce 0')
                op=sr.getstatusoutput('hadoop-daemon.sh start datanode')
                print('\n\t\t>>  DataNode Configured AND Started  <<')
                input('\nPress enter key to continue...')
            elif ch=='3':
                ip=input('Enter IP of NameNode :  ')
                port=input('Enter The Port No. :  ')
                print('\n\t\t>> Please Wait...')
                op=sr.getstatusoutput('rpm -i jdk-8u171-linux-x64.rpm --force')
                if op[0]==0:
                    print('\n\t\t>>  JDK Installed  <<')
                op=sr.getstatusoutput('rpm -i hadoop-1.2.1-1.x86_64.rpm --force')
                if op[0]==0:
                    print('\n\t\t>>  Hadoop Installed  <<')
                obj=open('/etc/hadoop/core-site.xml','w+')
                txt='<configuration>\n<property>\n<name>fs.default.name</name>\n<value>hdfs://{0}:{1}</value>\n</property>\n</configuration>'.format(ip,port)
                obj.writelines(txt)
                obj.close()
                print('\n\t\t>>  Client Configured  <<')
                input('\nPress enter key to continue...')
        
        elif a=='6':
            dns=input('\n\t\t >>  IP OR Domain Name Of The Server :  ')
            os.system('ping -c 4 {}'.format(dns))
            input('\nPress enter key to continue...')
        elif a=='7':
            os.system('clear')
            exit()


#Remote System
elif sys=='1':
    os.system('clear')
    rip=input('\n\t\t >>  Enter IP Of The  Remote System :  ')
    print('\n\t\t >>  Creating and Copying Public/Private Key-Pair')
    print('\n\t\tType Password Of The Remote System Below(If Prompted) :-\n\n')
    os.system('ssh-copy-id root@{}'.format(rip))
    while True:
        os.system('clear')
        os.system('tput setaf 7')
        print('''
    \t\t 1. Show Current Date
    \t\t 2. Show Current Time
    \t\t 3. Show My Private IP
    \t\t 4. Configure Web Server
    \t\t 5. Configure HDFS Cluster
    \t\t 6. Ping a Server
    \t\t 7. Exit''')
        a=input('Enter your choice : ')
        if a=='1':
            op=sr.getstatusoutput("ssh {} date +%d/%m/%Y".format(rip))
            os.system('tput setaf 7')
            print("\n\t\tToday's date is  >>  {}\n".format(op[1]))
            input('\nPress enter key to continue...')
        elif a=='2':
            op=sr.getstatusoutput('ssh {} date +%I:%M:%S'.format(rip))
            os.system('tput setaf 7')
            print("\n\t\tCurrent Time Is  >>  {}\n".format(op[1]))
            input('\nPress enter key to continue...')
        elif a=='3':
            print('\t\t>> Please Wait...\n')
            print("Your Private IP Is  >>  {}".format(rip))
            input('\nPress enter key to continue...')
        elif a=='4':
            print('\n\t\t >>Please wait...')
            op=sr.getstatusoutput('ssh root@{} dnf install httpd'.format(rip))
            if op[0]==0:
                print('\n\t\t>>  HTTPD Installed  <<')
            op=sr.getstatusoutput('ssh root@{} systemctl start httpd'.format(rip))
            if op[0]==0:
                print('\n\t\t>>  Service Started  <<')
            obj=open('/root/test@2580.html','w+')
            txt='Hi, this is a pre-created webpage'
            obj.writelines(txt)
            obj.close()
            op=sr.getstatusoutput('scp /root/test@2580.html root@{}:/var/www/html/default.html'.format(rip))
            os.system('rm -f /root/test@2580.html')
            print("\n\t\t>>  An html Page In The Name of 'default.html' Is Created \n\t\tIn The Root Directory of The Web Server <<")
            print('\n\t\t>>  Web Server Configured  <<')
            input('\nPress enter key to continue...')
        elif a=='5':
            print('''\t\tWhat Do You Want To Configure?
            \t\t  1. NameNode
            \t\t  2. DataNode
            \t\t  3. Client''')
            ch=input('\t\tEnter Your Selection :  ')
            if ch=='1':
                loc=input('Enter The Directory :  ')
                port=input('Enter The Port No. :  ')
                print('\n\t\t>> Please Wait...')
                op=sr.getstatusoutput('ssh root@{} rpm -i jdk-8u171-linux-x64.rpm --force'.format(rip))
                if op[0]==0:
                    print('\n\t\t>>  JDK Installed  <<')
                op=sr.getstatusoutput('ssh root@{} rpm -i hadoop-1.2.1-1.x86_64.rpm --force'.format(rip))
                if op[0]==0:
                    print('\n\t\t>>  Hadoop Installed  <<')
                obj=open('/root/test@2580.xml','w+')
                txt='<configuration>\n<property>\n<name>dfs.name.dir</name>\n<value>{}</value>\n</property>\n</configuration>'.format(loc)
                obj.writelines(txt)
                obj.close()
                op=sr.getstatusoutput('scp /root/test@2580.xml root@{}:/etc/hadoop/hdfs-site.xml'.format(rip))
                op=sr.getstatusoutput('rm -f test@2580.xml')
                obj=open('/root/test@2580.xml','w+')
                txt='<configuration>\n<property>\n<name>fs.default.name</name>\n<value>hdfs://{0}:{1}</value>\n</property>\n</configuration>'.format(rip,port)
                obj.writelines(txt)
                obj.close()
                op=sr.getstatusoutput('scp /root/test@2580.xml root@{}:/etc/hadoop/core-site.xml'.format(rip))
                os.system('rm -f test@2580.xml')
                os.system('ssh root@{} rm -rf {}'.format(rip,loc))
                os.system('ssh root@{} mkdir {}'.format(rip,loc))
                print('\n\t\t>>  Formatting NameNode Directory  <<')
                print('\n\t\t>>  Enter "Y" In The Upcoming Prompt :-')
                os.system('ssh root@{} hadoop namenode -format'.format(rip))
                os.system('ssh root@{} systemctl stop firewalld'.format(rip))
                os.system('ssh root@{} setenforce 0'.format(rip))
                op=sr.getstatusoutput('ssh root@{} hadoop-daemon.sh start namenode'.format(rip))
                print('\n\t\t>>  NameNode Configured AND Started  <<')
                input('\nPress enter key to continue...')

            elif ch=='2':
                ip=input('Enter IP of NameNode :  ')
                loc=input('Enter The Directory :  ')
                port=input('Enter The Port No. :  ')
                print('\n\t\t>> Please Wait...')
                op=sr.getstatusoutput('ssh root@{} rpm -i jdk-8u171-linux-x64.rpm --force'.format(rip))
                if op[0]==0:
                    print('\n\t\t>>  JDK Installed  <<')
                op=sr.getstatusoutput('ssh root@{} rpm -i hadoop-1.2.1-1.x86_64.rpm --force'.format(rip))
                if op[0]==0:
                    print('\n\t\t>>  Hadoop Installed  <<')
                obj=open('/root/test@2580.xml','w+')
                txt='<configuration>\n<property>\n<name>dfs.data.dir</name>\n<value>{}</value>\n</property>\n</configuration>'.format(loc)
                obj.writelines(txt)
                obj.close()
                op=sr.getstatusoutput('scp /root/test@2580.xml root@{}:/etc/hadoop/hdfs-site.xml'.format(rip))
                op=sr.getstatusoutput('rm -f test@2580.xml')
                obj=open('/root/test@2580.xml','w+')
                txt='<configuration>\n<property>\n<name>fs.default.name</name>\n<value>hdfs://{0}:{1}</value>\n</property>\n</configuration>'.format(ip,port)
                obj.writelines(txt)
                obj.close()
                op=sr.getstatusoutput('scp /root/test@2580.xml root@{}:/etc/hadoop/core-site.xml'.format(rip))
                os.system('rm -f test@2580.xml')
                os.system('ssh root@{} rm -rf {}'.format(rip,loc))
                os.system('ssh root@{} mkdir {}'.format(rip,loc))
                os.system('ssh root@{} systemctl stop firewalld'.format(rip))
                os.system('ssh root@{} setenforce 0'.format(rip))
                op=sr.getstatusoutput('ssh root@{} hadoop-daemon.sh start datanode'.format(rip))
                print('\n\t\t>>  DataNode Configured AND Started  <<')
                input('\nPress enter key to continue...')

            elif ch=='3':
                ip=input('Enter IP of NameNode :  ')
                port=input('Enter The Port No. :  ')
                print('\n\t\t>> Please Wait...')
                op=sr.getstatusoutput('ssh root@{} rpm -i jdk-8u171-linux-x64.rpm --force'.format(rip))
                if op[0]==0:
                    print('\n\t\t>>  JDK Installed  <<')
                op=sr.getstatusoutput('ssh root@{} rpm -i hadoop-1.2.1-1.x86_64.rpm --force'.format(rip))
                if op[0]==0:
                    print('\n\t\t>>  Hadoop Installed  <<')
                obj=open('/root/test@2580.xml','w+')
                txt='<configuration>\n<property>\n<name>fs.default.name</name>\n<value>hdfs://{0}:{1}</value>\n</property>\n</configuration>'.format(ip,port)
                obj.writelines(txt)
                obj.close()
                op=sr.getstatusoutput('scp /root/test@2580.xml root@{}:/etc/hadoop/core-site.xml'.format(rip))
                os.system('rm -f test@2580.xml')
                print('\n\t\t>>  Client Configured  <<')
                input('\nPress enter key to continue...')
        elif a=='6':
            dns=input('\n\t\t >>  IP OR Domain Name Of The Server :  ')
            os.system('ssh root@{} ping -c 4 {}'.format(rip,dns))
            input('\nPress enter key to continue...')
        elif a=='7':
            os.system('clear')
            exit()